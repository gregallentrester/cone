package com.example.howtodoinjava.springhystrixstudentservice.util;

import java.util.Collections;

import org.springframework.boot.actuate.info.Info;
import org.springframework.boot.actuate.info.InfoContributor;

import org.springframework.stereotype.Component;


@Component
public class SpringEurekaClientStudentServiceInfoContributor implements InfoContributor {

	@Override
	public void contribute(Info.Builder builder) {

		builder.
			withDetail(
				"details",
				Collections.singletonMap(
				  "description",
					"The Student-details microservice is discovery-server-aware, " +
					"and is called by the dicovery-server-aware School Microservice."));
	}
}
