package com.example.howtodoinjava.springhystrixstudentservice.controller;

import java.util.*;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.howtodoinjava.springhystrixstudentservice.domain.Student;


@RestController
public class StudentServiceController {

	private static Map<String, List<Student>> schoolDB =
	  new HashMap<String, List<Student>>();

	static {

		schoolDB = new HashMap<String, List<Student>>();

		List<Student> list = new ArrayList();

		list.add(new Student("Drake", "Class IV"));
		list.add(new Student("Paula", "Class V"));

		schoolDB.put("abcschool", lst);

		list = new ArrayList();
		list.add(new Student("Greta", "Class III"));
		list.add(new Student("Carmen", "Class VI"););

		schoolDB.put("xyzschool", list);
	}

	@RequestMapping(value = "/getStudentDetailsForSchool/{schoolname}", method = RequestMethod.GET)
	public List<Student> getStudents(@PathVariable String schoolname) {

		System.out.println("Getting Student details for " + schoolname);

		List<Student> studentList =
			schoolDB.get(schoolname);

		if (studentList == null) {

			studentList = new ArrayList();
			studentList.add(new Student("Not Found", "N/A"));
		}

		return studentList;
	}
}
