package com.example.howtodoinjava.springhystrixstudentservice.domain;

public class Student {

	private String name, className;


	public Student(String nameA, String classNameA) {
		name = nameA;
		className = classNameA;
	}

	public String getName() { return name; }
	public void setName(String value) { name = value; }

	public String getClassName() { return className; }
	public void setClassName(String value) { className = value; }
}
